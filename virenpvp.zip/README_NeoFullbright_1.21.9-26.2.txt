NeoFullbright 8.0 - 1.21.9 / 26.2
By pierrecreeper

Changements :
- Description pack.mcmeta : §6NeoFullbright §b1.21.9 - 26.2 §b| §dBy pierrecreeper §8©
- Ancien watermark PNG supprimé : plus de vignette.png custom pour écrire le texte.
- Texte demandé : NeoFullbright 8.0, rendu en caractères pixel/GLSL directement dans les shaders.
- Ton fichier .fsh d'indice est conservé dans assets/neofullbright/shader_hint/ et adapté en position_color.fsh.
- Marquages intégrés : NeoFullbright copyright, NeoFullbright copirite/copyright, NeoFullbright by pierrecreeper.

Note : le texte est généré par shader, sans image de watermark. Je ne peux pas confirmer le rendu en jeu depuis cet environnement.
