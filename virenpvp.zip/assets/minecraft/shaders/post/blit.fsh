#version 330
uniform sampler2D InSampler;
layout(std140) uniform BlitConfig{vec4 ColorModulate;};
in vec2 texCoord;
out vec4 fragColor;

/*NeoFullbright copyright|NeoFullbright copirite|NeoFullbright by pierrecreeper|NeoFullbright 8.0|shader glyphs no image*/
#define  _SPACE  0u
#define      _A  488621617u
#define      _B  1025459774u
#define      _C  488129070u
#define      _D  1025033790u
#define      _E  1057964575u
#define      _F  1057964560u
#define      _G  488132142u
#define      _H  589284913u
#define      _I  474091662u
#define      _J  237046348u
#define      _K  589982257u
#define      _L  554189343u
#define      _M  599442993u
#define      _N  597347889u
#define      _O  488162862u
#define      _P  1025458704u
#define      _Q  488166989u
#define      _R  1025459761u
#define      _S  520553534u
#define      _T  1044516996u
#define      _U  588826158u
#define      _V  588818756u
#define      _W  588830378u
#define      _X  581052977u
#define      _Y  581046404u
#define      _Z  1042424351u
#define _PARENL  142876932u
#define _PARENR  136382532u
#define _RSLASH  35787024u
#define _LSLASH  545394753u
#define    _DOT  4u
#define  _COMMA  68u
#define   _HASH  368389098u
#define      _1  147460255u
#define      _2  487657759u
#define      _3  487654958u
#define      _4  73747426u
#define      _5  1057949230u
#define      _6  487540270u
#define      _7  1041305732u
#define      _8  488064558u
#define      _9  488080942u
#define      _0  490399278u
#define _USCORE  31u
#define   _DASH  1015808u
#define   _PLUS  139432064u
#define      _e  15269391u
#define      _o  15255086u
#define      _u  18400877u
#define      _l  406982798u
#define      _b  554649150u
#define      _r  32031248u
#define      _i  134615182u
#define      _g  16301118u
#define      _h  554649137u
#define      _t  139399302u
#define _CW 5
#define _CH 6
#define _PAD 1
#define CHARSCALE 2
#define PADDING (CHARSCALE*_PAD)
#define CHARWIDTH (CHARSCALE*_CW)
#define CHARHEIGHT (CHARSCALE*_CH)
#define CHARPADDEDWIDTH (CHARWIDTH+PADDING)
#define ORIGIN ivec2(25,25)
#define CHARCOUNT 17
#define STRING uint[](_N,_e,_o,_F,_u,_l,_l,_b,_r,_i,_g,_h,_t,_SPACE,_8,_DOT,_0)
bool NeoFullbright_by_pierrecreeper_getPixel(uint NeoFullbright_by_pierrecreeper_character,int x,int y){return ((NeoFullbright_by_pierrecreeper_character>>(4-x+y*5))&1u)==1u;}
float NeoFullbright_by_pierrecreeper_textPixel(vec2 NeoFullbright_by_pierrecreeper_frag){ivec2 NeoFullbright_by_pierrecreeper_pixel=ivec2(NeoFullbright_by_pierrecreeper_frag);ivec2 NeoFullbright_by_pierrecreeper_offset=NeoFullbright_by_pierrecreeper_pixel-ORIGIN;if(NeoFullbright_by_pierrecreeper_offset.x>=0&&NeoFullbright_by_pierrecreeper_offset.y>=0&&NeoFullbright_by_pierrecreeper_offset.x<(CHARPADDEDWIDTH)*CHARCOUNT-PADDING&&NeoFullbright_by_pierrecreeper_offset.y<CHARHEIGHT){uint[] NeoFullbright_by_pierrecreeper_text=STRING;int NeoFullbright_by_pierrecreeper_index=NeoFullbright_by_pierrecreeper_offset.x/CHARPADDEDWIDTH;NeoFullbright_by_pierrecreeper_offset.x-=NeoFullbright_by_pierrecreeper_index*CHARPADDEDWIDTH;if(NeoFullbright_by_pierrecreeper_offset.x<CHARWIDTH){return NeoFullbright_by_pierrecreeper_getPixel(NeoFullbright_by_pierrecreeper_text[NeoFullbright_by_pierrecreeper_index],NeoFullbright_by_pierrecreeper_offset.x/CHARSCALE,NeoFullbright_by_pierrecreeper_offset.y/CHARSCALE)?1.0:0.0;}}return 0.0;}
vec4 NeoFullbright_by_pierrecreeper_applyText(vec4 NeoFullbright_by_pierrecreeper_base){float NeoFullbright_by_pierrecreeper_shadow=NeoFullbright_by_pierrecreeper_textPixel(gl_FragCoord.xy-vec2(2.0,-2.0));float NeoFullbright_by_pierrecreeper_text=NeoFullbright_by_pierrecreeper_textPixel(gl_FragCoord.xy);if(NeoFullbright_by_pierrecreeper_shadow>0.5){NeoFullbright_by_pierrecreeper_base=vec4(mix(NeoFullbright_by_pierrecreeper_base.rgb,vec3(0.0),0.72),max(NeoFullbright_by_pierrecreeper_base.a,1.0));}if(NeoFullbright_by_pierrecreeper_text>0.5){NeoFullbright_by_pierrecreeper_base=vec4(vec3(1.0),max(NeoFullbright_by_pierrecreeper_base.a,1.0));}return NeoFullbright_by_pierrecreeper_base;}
/*NeoFullbright by pierrecreeper|do not remove copyright glyph code*/

void main(){vec4 NeoFullbright_by_pierrecreeper_color=texture(InSampler,texCoord)*ColorModulate;fragColor=NeoFullbright_by_pierrecreeper_applyText(NeoFullbright_by_pierrecreeper_color);}/*NeoFullbright copyright|NeoFullbright by pierrecreeper|post no image text*/
