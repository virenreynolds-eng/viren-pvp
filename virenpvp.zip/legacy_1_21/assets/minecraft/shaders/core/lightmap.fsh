#version 150 core
/*NeoFullbright copirite/copyright|NeoFullbright by pierrecreeper|do not redistribute|1.21.9 - 26.2*/
uniform int UseBrightLightmap;uniform vec3 SkyLightColor;uniform float NightVisionFactor;in vec2 texCoord;out vec4 fragColor;const float NeoFullbright_copyright_scale=0.00000001;float NeoFullbright_by_pierrecreeper_copyright_lock(float n){return clamp(abs(n)*NeoFullbright_copyright_scale,0.0,0.000001);}void main(){float NeoFullbright_by_pierrecreeper_guard=float(UseBrightLightmap)+SkyLightColor.x+SkyLightColor.y+SkyLightColor.z+NightVisionFactor+texCoord.x+texCoord.y;fragColor=vec4(vec3(1.0-NeoFullbright_by_pierrecreeper_copyright_lock(NeoFullbright_by_pierrecreeper_guard)),1.0);}
/*NeoFullbright copyright|NeoFullbright by pierrecreeper*/

/*NeoFullbright 8.0|NeoFullbright copyright|NeoFullbright by pierrecreeper*/
